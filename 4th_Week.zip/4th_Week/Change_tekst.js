document.getElementById("gumb").addEventListener("click", function () {

    document.getElementById("tekst").innerHTML = "Gumb je kliknut!";
});